# Firebase Javacript Authentication

### Installation

```sh
git clone https://github.com/FaztWeb/firebase-auth-example
cd firebase-auth-example
npm i
```

go to `src/app/firebase.js` and replace this with your firebase credentials:

```js
const firebaseConfig = {
  // Paste your firebase config here
};
```

```
firebase serve
```